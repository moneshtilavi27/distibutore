<?php
$conn=mysqli_connect("localhost","root","","shop");
if(!$conn)
{
		echo "connected";
}
?>